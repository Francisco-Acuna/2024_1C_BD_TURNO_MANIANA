/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase01;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hola Mundo!!");

        //comentarios
        
        //este es un comentario en línea
        //si queremos seguir escribiendo debajo debemos agregar //
        
        /*
        Bloque de comentarios
        podemos escribir
        en varias líneas
         */
        
        /**
         * Este es un comentario JavaDoc se puede escribir en varias líneas se
         * utiliza para documentar clases, interfaces, métodos
         */
        
        //sout + tab atajo de teclado para imprimir por consola
        System.out.println("Hello World!");
        //esto es una sentencia
        //una sentencia es una orden que se le da al programa
        //para que realice una tarea específica
        //las sentencias deben terminar con ;
        //el ; es el separador de sentencias

        //impresión con salto de línea
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
        System.out.println("4");
        System.out.println("5");

        //impresión sin salto de línea
        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.print("4");
        System.out.print("5");

        System.out.println("");

        //Variables
        
        int a; // declaración de variable
        //tiene un tipo de dato (int) y un identificador (a)
        a = 2; // asignación de valor a la variable
        int b = 3; //declaración y asignación en una misma línea
        a = 4; //cambio el valor de la variable
//        a = "hola";  error no puedo asignar otro tipo de dato

    }

}
